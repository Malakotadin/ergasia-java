package Heelo;
import java.lang.reflect.Array;
import java.util.ArrayList;
import  java.util.Scanner;
public class Courses {
    String course_name;
    int ect;
    int semester;



    public Courses(String course_name, int ect, int semester){


    }
    public static void main(String[] args) {
        Courses courses = new Courses("math", 2, 3);
    }

    static void updatel_List(){
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> course= new ArrayList<String>();
        course.add(scanner.nextLine());

    }
}
