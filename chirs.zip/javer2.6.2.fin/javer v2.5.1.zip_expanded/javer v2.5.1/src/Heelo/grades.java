package Heelo;

public class grades{
    int grade;
    int exam_period;//θα το βλεπω σαν εξαμηνο αυτο
    String course_name;
    String student_name;
    
    @Override
    public String toString (){
    	
    	return this.student_name;
    }
}
//course_name
