
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<link REL=STYLESHEET
      HREF="StyleSheet.css"
      TYPE="text/css">

<title>HomeSpage</title>
</head>
<body>
<br>
<h1>Καλώς ήρθατε!<br>Ποιά είναι η ιδιότητά σας; </h1>
<br><br>
<h2>Μαθητής</h2>
<br><br><br>
<h2>Καθηγητής</h2>
<br><br><br>
<h2><a href="login.jsp">Γραμματεία<a></h2>
</body>
</html>