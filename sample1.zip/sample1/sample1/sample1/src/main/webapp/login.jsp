<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>


<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<link REL=STYLESHEET
      HREF="StyleSheet.css"
      TYPE="text/css">

    <title>login page</title>
</head>
      <body>
      <br>
      <h1>Login</h1>

      <div class="form-container">
        <table class="center">
        <form action="login" method="post">
          <thead>
            <tr>
              <th>Εισάγετε τα στοιχεία σας</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
              <label>Username:</label>
              <input type="text" name="username"/></td>
            </tr>
            <tr>
              <td>
              <label>Password:</label>
              <input type="password" name="password" /></td>
            </tr>
            <tr>
              <td><button type="submit"> login </button></td>
            </tr>
          </tbody>
          </form>
        </table>
      </div>

      </body>
</html>