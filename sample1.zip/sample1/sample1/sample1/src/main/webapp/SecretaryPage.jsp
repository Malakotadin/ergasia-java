<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<% if(session.getAttribute("username")==null)
        response.sendRedirect("login.jsp");%>

<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<link REL=STYLESHEET
      HREF="StyleSheet.css"
      TYPE="text/css">

    <title>Secretary page</title>
</head>
    <body>
        <br><br>
        <button><a href="CourseList.jsp">Προβολή μαθημάτων</a></button>
        <br><br><br>
        <button><a href="ProfPerCourse.jsp">Προβολή μαθημάτων και<br>υπεύθυνων καθηγητών</a></button>
        <br><br><br>
        <button><a href="AssignCourse.jsp">Ανάθεση μαθήματος <br> σε καθηγητή</a></button>
        <br>
    </body>
</html>