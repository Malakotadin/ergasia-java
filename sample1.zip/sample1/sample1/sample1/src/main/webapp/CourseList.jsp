<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<link REL=STYLESHEET
      HREF="StyleSheet.css"
      TYPE="text/css">

    <title>Course List</title>
</head>
    <body>

        malakia kwdikas gia to db me allo paradeigma apo
        https://www.codejava.net/java-ee/jsp/how-to-create-dynamic-drop-down-list-in-jsp-from-database

    <select name="category">
        <c:forEach items="${listCategory}" var="category">
            <option value="${category.id}">${category.name}</option>
        </c:forEach>
    </select>
    <%-- Note that the value for the attribute items must match the name of the corresponding attribute set in the servlet class.
    As you can see, the values of the drop down list are the IDs of the categories.--%>



    <table border=1>
            <thead>
                <tr>
                    <th>Course Name</th>
                    //<th colspan=2>Action</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach items="${requestScope.Courses}" var="c">
                    <tr>
                        <td><c:out value="${c.courseName}" /></td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>




    </body>
</html>