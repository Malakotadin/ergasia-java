package com.controller;

import java.io.IOException;

//import com.dao.StudentDao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.dao.SecretaryDao;
import com.model.Secretary;

@WebServlet("/secretary")
public class SecretaryController extends HttpServlet {

    private static String Login = "/login.jsp";

    private SecretaryDao dao;
    private Secretary secretary; //gia otan diavasw dedomena ap th vash

    public SecretaryController() {
        super();
        dao = new SecretaryDao();
    }
 // vazw to function gia login sth grammateia alla isws einai kalh idea na ftiajw ena diaforetiko servlet gia login
 // gia na mporoun na to xrhsimopoihsoun oloi oi xrhstes
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String forward = "";
        String action = request.getParameter("action");
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");

        if (action.equalsIgnoreCase("login")) {

        }
    }

    //grafei me post ti evale o xrhsths sta pedia username kai password
    // .entity @bean h klash ftiaxnei beans monh ths?

}
