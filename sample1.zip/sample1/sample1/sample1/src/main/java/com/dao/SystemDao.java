package com.dao;

public class SystemDao {
    // servlet gia login gia olous? apo mathhma
    //kalw sqlqueries mesa apo controller
    //me to pou kanei log in o xrhsths dhmiourgeitai to session
    //methodos gia check username kaai password me sql query, orisma username p egrapse o xrhsths otan phge na kanei log in
    //public String loginusernameCheck(String username){

    //}

    //password check sunarthsh
    //public String passwordCheck(String username, String plainTextPassword){
    //
    // }

    //Bcrypt dependency sto pom tou maven?

    //get role gia na doume ti einai o kathe user pou kanei log in, to opoio de jerw an xreiazomai akrivws gt to dialegoun sth prwth selida se emena
    //
}
