package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.model.Secretary;

public class SecretaryDao {
    String databaseURL  = "jdbc:postgresql://localhost:8080/secretary";// /student
    String username = "postgres";
    String password = "database";

    public List<Secretary> list() throws SQLException {
        List<Secretary> listCategory = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(databaseURL, username, password)) {
            String sql = "SELECT * FROM category ORDER BY name";
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(sql);

            while (result.next()) {
                int id = result.getInt("category_id");
                String name = result.getString("name");
                Category category = new Category(id, name);

                listCategory.add(category);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            throw ex;
        }

        return listCategory;
    }

}
