package com.dao;

public class ProfessorDao {
}
