package com.model;

import java.util.List;

public class Secretary {

    private int id;
    private String name;
    private String surname;
    private String department;
    private String username;
    private String password;
    private List<Double> grades; //mallon tha prepei na kanw klash users h' kati gia ta courses gia na mporoun na ta doun oloi? de jerw apo pou tha ta parw



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

}
