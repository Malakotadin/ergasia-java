package com.dao;

import java.sql.*;

public class loginDao {

    String databaseURL  = "jdbc:postgresql://localhost:8080/student";
    String username = "postgres";
    String password = "database";

    String loginCred="SELECT * FROM login WHERE username=? AND password=?";

    public boolean check(String username, String password)
    {
        try{
            // Load the PostgreSQL JDBC driver
            Class.forName("org.postgresql.Driver");

            // Establish the connection
            Connection con = DriverManager.getConnection(databaseURL, username, password);

            System.out.println("Connected to PostgreSQL database!");

            PreparedStatement st = con.prepareStatement(loginCred);
            st.setString(1,username);
            st.setString(2,password);
            ResultSet rs = st.executeQuery();
            if(rs.next())
            {
                return true;
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return false;
    }
}
