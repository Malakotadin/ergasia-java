package com;
//ola ta jakarta sto import htan javax kai ta allaja giati de douleuan what could go wrong
import java.io.IOException;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
//import Classes.Users;
//import Database.DatabaseRequests;
//import General.General;

//mporw na to valw sta controllers

import com.dao.SystemDao;


import com.controller.SecretaryController;
import com.dao.SecretaryDao;
import com.model.Secretary;
import com.dao.loginDao;

@WebServlet("/login")
public class login extends HttpServlet {

    public login() {
        super();
        // TODO Auto-generated constructor stub
    }


    private static final long serialVersionUID = 1L;
    private SystemDao dao;
    private loginDao loginDao=new loginDao();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        /*String username =request.getParameter("username");   originally olo auto htan edw alla de thelw na pairnw kwdiko me doGet opote fantazomai kalutera sto doPost
        String password =request.getParameter("password");
        String forward = "";
        String action = request.getParameter("action");
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");

        //if (action.equalsIgnoreCase("login")) {

        //}

    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        /*String username = request.getParameter("username");
        String password = request.getParameter("password");
        String user_type = request.getParameter("user_type");

        if(username == null || password == null) {
            request.setAttribute("error_message", "Complete all fields!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }*/

        String username =request.getParameter("username");
        String password =request.getParameter("password");
        String forward = "";
        //String action = request.getParameter("action");
        response.setContentType("text/html; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        //kanw set ena default username kai password gia na mhn mplejw me th vash
        if(username.equals("admin") && password.equals("123")){

            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            //response.sendRedirect("SecretaryPage.jsp");
            request.getRequestDispatcher("SecretaryPage.jsp").forward(request, response);
            //session.setMaxInactiveInterval(2);

            //otan kanw refresh sto secretary page de me petaei sto login page hmm giati
        }
        else {
            request.getRequestDispatcher("login.jsp").forward(request, response);
            //response.sendRedirect("login.jsp");
        }


        /* ---------------- DB LOGIN VERSION--------------------
        if(loginDao.check(username,password)){

            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            request.getRequestDispatcher("SecretaryPage.jsp").forward(request, response);

        }
        else {
            request.getRequestDispatcher("login.jsp").forward(request, response);

        }*/



        /*try {
            if (user_type.equals("admin")) {
                user = DatabaseRequests.selectAdmin(username, General.hashing(password));
            }
        } catch (SQLException e) {
        e.printStackTrace();
        }*/

    }



}
