/**
 * 
 */
/**
 * 
 */

module Javer {
	requires java.sql;
    requires jakarta.servlet;
}